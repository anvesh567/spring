package com.pawana.currency.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pawana.currency.vo.Exchange;

@Service
public class CurrencyCalculationServiceImpl implements CurrencyCalculationService {
	
	private final String EXCHANGE_URI = "/exchange/source/{source}/destination/{destination}";

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${exchange.base.url}")
	private String baseUrl;

	@Override
	public String calculateAmount(String source, String destination, String exchangeAmount) {
		HttpHeaders header = new HttpHeaders();
		//header.set("Autherization", "bearer tokenId");
		header.set("Content-Type", "application/json");
		
		HttpEntity<HttpHeaders>  entity = new HttpEntity<>(header);
		
		ResponseEntity<Exchange> response = restTemplate.exchange(baseUrl+EXCHANGE_URI, HttpMethod.GET, entity, Exchange.class, source,destination);
		
		if(response != null) {
			Exchange exchange = response.getBody();
			
			if(exchange != null) {
				return ""+(new BigDecimal(exchangeAmount).multiply(new BigDecimal(exchange.getExchange())));
			}
		}
		
		return null;
	}

}
