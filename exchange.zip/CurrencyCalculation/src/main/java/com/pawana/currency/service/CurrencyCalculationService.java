package com.pawana.currency.service;

public interface CurrencyCalculationService {
	
	public String calculateAmount(String source,String destination,String exchangeAmount);

}
